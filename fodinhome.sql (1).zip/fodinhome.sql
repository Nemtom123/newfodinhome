-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2021. Júl 27. 07:25
-- Kiszolgáló verziója: 10.4.19-MariaDB
-- PHP verzió: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `fodinhome`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `aloldalak`
--

CREATE TABLE `aloldalak` (
  `al_oldalak_id` int(255) NOT NULL,
  `al_oldalak_1` longtext COLLATE utf8mb4_bin NOT NULL,
  `al_oldalak_2` longtext COLLATE utf8mb4_bin NOT NULL,
  `al_oldalak_1_en` longtext COLLATE utf8mb4_bin NOT NULL,
  `al_oldalak_2_en` longtext COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- A tábla adatainak kiíratása `aloldalak`
--

INSERT INTO `aloldalak` (`al_oldalak_id`, `al_oldalak_1`, `al_oldalak_2`, `al_oldalak_1_en`, `al_oldalak_2_en`) VALUES
(5, '<p>w</p>', '<p>w</p>', '<p>w</p>', '<p>w</p>'),
(6, '<p>oldal11 szerkesztése</p>', '<p>oldal11 szerkesztése</p>', '<p>oldal11 szerkesztése angolul</p>', '<p>oldal11 szerkesztése vangolul</p>'),
(7, '<p>oldal12 szerkesztése</p>', '<p>oldal12 szerkesztése</p>', '<p>oldal12 szerkesztése EN</p>', '<p>oldal12 szerkesztése ang</p>'),
(10, '<p>oldal15 szerkesztése</p>', '<p>oldal15 szerkesztése</p>', '<p>oldal15 szerkesztése EN</p>', '<p>oldal15 szerkesztése EN</p>'),
(11, '<p>oldal16 szerkesztése</p>', '<p>oldal16 szerkesztése</p>', '<p>oldal16 szerkesztése angolul</p>', '<p>oldal16 szerkesztése angolul</p>'),
(12, '<p>oldal17 szerkesztése</p>', '<p>oldal17 szerkesztése</p>', '<p>oldal17 szerkesztése angolul</p>', '<p>oldal17 szerkesztése angolul</p>'),
(15, '<h2>BEMUTATKOZÁS</h2><p>&nbsp;</p><h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2>BEMUTATKOZÁS</h2><p>&nbsp;</p><h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '', ''),
(16, '', '', '<p>sss</p>', '<p>sss</p>');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `footer`
--

CREATE TABLE `footer` (
  `footer_id` int(255) NOT NULL,
  `egy_szakasz_egy` varchar(255) NOT NULL,
  `egy_szakasz_ketto` varchar(255) NOT NULL,
  `egy_szakasz_harom` varchar(255) NOT NULL,
  `egy_szakasz_negy` varchar(255) NOT NULL,
  `egy_szakasz_link_egy` varchar(255) NOT NULL,
  `egy_szakasz_link_ketto` varchar(255) NOT NULL,
  `egy_szakasz_link_harom` varchar(255) NOT NULL,
  `ketto_szakasz_egy` varchar(255) NOT NULL,
  `ketto_szakasz_ketto` varchar(255) NOT NULL,
  `ketto_szakasz_harom` varchar(255) NOT NULL,
  `ketto_szakasz_negy` varchar(255) NOT NULL,
  `ketto_szakasz_link_egy` varchar(255) NOT NULL,
  `ketto_szakasz_link_ketto` varchar(255) NOT NULL,
  `ketto_szakasz_link_harom` varchar(255) NOT NULL,
  `harom_szakasz_egy` varchar(255) NOT NULL,
  `harom_szakasz_ketto` varchar(255) NOT NULL,
  `harom_szakasz_harom` varchar(255) NOT NULL,
  `harom_szakasz_negy` varchar(255) NOT NULL,
  `harom_szakasz_link_egy` varchar(255) NOT NULL,
  `harom_szakasz_link_ketto` varchar(255) NOT NULL,
  `harom_szakasz_link_harom` varchar(255) NOT NULL,
  `negy_szakasz_egy` varchar(255) NOT NULL,
  `negy_szakasz_ketto` varchar(255) NOT NULL,
  `negy_szakasz_harom` varchar(255) NOT NULL,
  `negy_szakasz_negy` varchar(255) NOT NULL,
  `negy_szakasz_link_egy` varchar(255) NOT NULL,
  `negy_szakasz_link_ketto` varchar(255) NOT NULL,
  `negy_szakasz_link_harom` varchar(255) NOT NULL,
  `ot_szakasz_egy` varchar(255) NOT NULL,
  `ot_szakasz_ketto` varchar(255) NOT NULL,
  `ot_szakasz_harom` varchar(255) NOT NULL,
  `ot_szakasz_negy` varchar(255) NOT NULL,
  `ot_szakasz_link_egy` varchar(255) NOT NULL,
  `ot_szakasz_link_ketto` varchar(255) NOT NULL,
  `ot_szakasz_link_harom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `footer`
--

INSERT INTO `footer` (`footer_id`, `egy_szakasz_egy`, `egy_szakasz_ketto`, `egy_szakasz_harom`, `egy_szakasz_negy`, `egy_szakasz_link_egy`, `egy_szakasz_link_ketto`, `egy_szakasz_link_harom`, `ketto_szakasz_egy`, `ketto_szakasz_ketto`, `ketto_szakasz_harom`, `ketto_szakasz_negy`, `ketto_szakasz_link_egy`, `ketto_szakasz_link_ketto`, `ketto_szakasz_link_harom`, `harom_szakasz_egy`, `harom_szakasz_ketto`, `harom_szakasz_harom`, `harom_szakasz_negy`, `harom_szakasz_link_egy`, `harom_szakasz_link_ketto`, `harom_szakasz_link_harom`, `negy_szakasz_egy`, `negy_szakasz_ketto`, `negy_szakasz_harom`, `negy_szakasz_negy`, `negy_szakasz_link_egy`, `negy_szakasz_link_ketto`, `negy_szakasz_link_harom`, `ot_szakasz_egy`, `ot_szakasz_ketto`, `ot_szakasz_harom`, `ot_szakasz_negy`, `ot_szakasz_link_egy`, `ot_szakasz_link_ketto`, `ot_szakasz_link_harom`) VALUES
(1, 'qawul', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'qq', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'qaaaaaa', 'q', 'q', 'q', 'qaaaaaaa', 'qaaaaaaa', 'qaaaaaaaaa');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `footeren`
--

CREATE TABLE `footeren` (
  `footer_id` int(255) NOT NULL,
  `egy_szakasz_egy` varchar(255) NOT NULL,
  `egy_szakasz_ketto` varchar(255) NOT NULL,
  `egy_szakasz_harom` varchar(255) NOT NULL,
  `egy_szakasz_negy` varchar(255) NOT NULL,
  `egy_szakasz_link_egy` varchar(255) NOT NULL,
  `egy_szakasz_link_ketto` varchar(255) NOT NULL,
  `egy_szakasz_link_harom` varchar(255) NOT NULL,
  `ketto_szakasz_egy` varchar(255) NOT NULL,
  `ketto_szakasz_ketto` varchar(255) NOT NULL,
  `ketto_szakasz_harom` varchar(255) NOT NULL,
  `ketto_szakasz_negy` varchar(255) NOT NULL,
  `ketto_szakasz_link_egy` varchar(255) NOT NULL,
  `ketto_szakasz_link_ketto` varchar(255) NOT NULL,
  `ketto_szakasz_link_harom` varchar(255) NOT NULL,
  `harom_szakasz_egy` varchar(255) NOT NULL,
  `harom_szakasz_ketto` varchar(255) NOT NULL,
  `harom_szakasz_harom` varchar(255) NOT NULL,
  `harom_szakasz_negy` varchar(255) NOT NULL,
  `harom_szakasz_link_egy` varchar(255) NOT NULL,
  `harom_szakasz_link_ketto` varchar(255) NOT NULL,
  `harom_szakasz_link_harom` varchar(255) NOT NULL,
  `negy_szakasz_egy` varchar(255) NOT NULL,
  `negy_szakasz_ketto` varchar(255) NOT NULL,
  `negy_szakasz_harom` varchar(255) NOT NULL,
  `negy_szakasz_negy` varchar(255) NOT NULL,
  `negy_szakasz_link_egy` varchar(255) NOT NULL,
  `negy_szakasz_link_ketto` varchar(255) NOT NULL,
  `negy_szakasz_link_harom` varchar(255) NOT NULL,
  `ot_szakasz_egy` varchar(255) NOT NULL,
  `ot_szakasz_ketto` varchar(255) NOT NULL,
  `ot_szakasz_harom` varchar(255) NOT NULL,
  `ot_szakasz_negy` varchar(255) NOT NULL,
  `ot_szakasz_link_egy` varchar(255) NOT NULL,
  `ot_szakasz_link_ketto` varchar(255) NOT NULL,
  `ot_szakasz_link_harom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `footeren`
--

INSERT INTO `footeren` (`footer_id`, `egy_szakasz_egy`, `egy_szakasz_ketto`, `egy_szakasz_harom`, `egy_szakasz_negy`, `egy_szakasz_link_egy`, `egy_szakasz_link_ketto`, `egy_szakasz_link_harom`, `ketto_szakasz_egy`, `ketto_szakasz_ketto`, `ketto_szakasz_harom`, `ketto_szakasz_negy`, `ketto_szakasz_link_egy`, `ketto_szakasz_link_ketto`, `ketto_szakasz_link_harom`, `harom_szakasz_egy`, `harom_szakasz_ketto`, `harom_szakasz_harom`, `harom_szakasz_negy`, `harom_szakasz_link_egy`, `harom_szakasz_link_ketto`, `harom_szakasz_link_harom`, `negy_szakasz_egy`, `negy_szakasz_ketto`, `negy_szakasz_harom`, `negy_szakasz_negy`, `negy_szakasz_link_egy`, `negy_szakasz_link_ketto`, `negy_szakasz_link_harom`, `ot_szakasz_egy`, `ot_szakasz_ketto`, `ot_szakasz_harom`, `ot_szakasz_negy`, `ot_szakasz_link_egy`, `ot_szakasz_link_ketto`, `ot_szakasz_link_harom`) VALUES
(1, 'qqqqqq', 'qqqrrrrrr', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'qaaaaa', 'qaaaaa', 'qaaaaaa');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `meta`
--

CREATE TABLE `meta` (
  `meta_id` int(20) NOT NULL,
  `metaleiras` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `metaleiras2` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_hungarian_ci NOT NULL,
  `oldalneve` varchar(2550) COLLATE utf8_hungarian_ci NOT NULL,
  `banner` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `banner2` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `banner3` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `meta`
--

INSERT INTO `meta` (`meta_id`, `metaleiras`, `metaleiras2`, `oldalneve`, `banner`, `banner2`, `banner3`, `h1`) VALUES
(0, 'we', 'w', '0...NavMenu\r\n', 'w', 'wwwwww', 'wwwwww', 'wwww'),
(1, 'bel', 'bel', '15...oldal2\r\n', 'bel', 'bel', 'bel', 'bel'),
(2, 'Épitészet, Festés, Mázolás, Tapétázás Miskolc', 'Miskolc', '2...index\r\n', 'Mázolás', 'Tapétázás', 'Festés', 'Bemutatkozás'),
(4, 'Tetőszerkesztés Miskolc', 'Tetőszerkesztés Miskolc', '4...oldal1\r\n', 'Tetőszerkesztés Miskolc', 'Tetőszerkesztés Miskolc', 'Tetőszerkesztés Miskolc', 'Tetőszerkesztés Miskolc'),
(5, '10', 'oldal', '5...oldal10\r\n', 'van', 'nem', 'ja', 'igen');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `navmenu`
--

CREATE TABLE `navmenu` (
  `nav_id` int(255) NOT NULL,
  `elnevezes` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `elnevezes_en` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- A tábla adatainak kiíratása `navmenu`
--

INSERT INTO `navmenu` (`nav_id`, `elnevezes`, `elnevezes_en`) VALUES
(1, 'Home', 'Homika'),
(2, 'Például', 'Example');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `oldalak`
--

CREATE TABLE `oldalak` (
  `oldalak_id` int(255) NOT NULL,
  `oldalak_szoveg_1` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_2` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_3` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_4` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_5` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_1_en` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_2_en` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_3_en` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_4_en` longtext COLLATE utf8mb4_bin NOT NULL,
  `oldalak_szoveg_5_en` longtext COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- A tábla adatainak kiíratása `oldalak`
--

INSERT INTO `oldalak` (`oldalak_id`, `oldalak_szoveg_1`, `oldalak_szoveg_2`, `oldalak_szoveg_3`, `oldalak_szoveg_4`, `oldalak_szoveg_5`, `oldalak_szoveg_1_en`, `oldalak_szoveg_2_en`, `oldalak_szoveg_3_en`, `oldalak_szoveg_4_en`, `oldalak_szoveg_5_en`) VALUES
(1, '', '', '', '', '', '<p>oldal19 szerkesztése angolul</p>', '<p>oldal19 szerkesztése angolul</p>', '<p>oldal19 szerkesztése angolul</p>', '<p>oldal19 szerkesztése angolul</p>', '<p>oldal19 szerkesztése angolul</p>'),
(2, '<h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p><p>&nbsp;</p>', '<h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><h2>&nbsp;</h2><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban.</p><p>&nbsp;Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe. Építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<p>DESCRIPTION\nBeautiful patterns framed by black window trims\n \n\nChoosing a dark colour for window frames or painting the trim black is a clever trick that can offer a number of benefits. Black is a timeless neutral. It has always been elegant and goes with everything. However, black is also a very strong colour and should be used in moderation. A few accent details are enough to make the decoration stand out. Black window frames can be such features.\n\nSince black is neutral, it can be combined with other neutrals to create pleasant and inviting decor. Anne Decker Architects, for example, chose black as the colour for window frames to create a more natural and seamless connection to the outdoors. The overall decor is nicely balanced. The black frames contrast with the white walls, while blending in better with the views.\n\nArchitect chose black for the thin window frames, but also for the stair railings, and it creates a beautiful cohesion in the space. The windows and staircase also add a graphic look to the decor. Moreover, the contrast between the black lines and the white walls and ceilings enlivens the space and gives it a fresh and bold look.\n\nTranslated with www.DeepL.com/Translator (free version)</p>', '<p>DESCRIPTION\nBeautiful patterns framed by black window trims\n \n\nChoosing a dark colour for window frames or painting the trim black is a clever trick that can offer a number of benefits. Black is a timeless neutral. It has always been elegant and goes with everything. However, black is also a very strong colour and should be used in moderation. A few accent details are enough to make the decoration stand out. Black window frames can be such features.\n\nSince black is neutral, it can be combined with other neutrals to create pleasant and inviting decor. Anne Decker Architects, for example, chose black as the colour for window frames to create a more natural and seamless connection to the outdoors. The overall decor is nicely balanced. The black frames contrast with the white walls, while blending in better with the views.\n\nArchitect chose black for the thin window frames, but also for the stair railings, and it creates a beautiful cohesion in the space. The windows and staircase also add a graphic look to the decor. Moreover, the contrast between the black lines and the white walls and ceilings enlivens the space and gives it a fresh and bold look.\n\nTranslated with www.DeepL.com/Translator (free version)</p>', '<p>DESCRIPTION\nBeautiful patterns framed by black window trims\n \n\nChoosing a dark colour for window frames or painting the trim black is a clever trick that can offer a number of benefits. Black is a timeless neutral. It has always been elegant and goes with everything. However, black is also a very strong colour and should be used in moderation. A few accent details are enough to make the decoration stand out. Black window frames can be such features.\n\nSince black is neutral, it can be combined with other neutrals to create pleasant and inviting decor. Anne Decker Architects, for example, chose black as the colour for window frames to create a more natural and seamless connection to the outdoors. The overall decor is nicely balanced. The black frames contrast with the white walls, while blending in better with the views.\n\nArchitect chose black for the thin window frames, but also for the stair railings, and it creates a beautiful cohesion in the space. The windows and staircase also add a graphic look to the decor. Moreover, the contrast between the black lines and the white walls and ceilings enlivens the space and gives it a fresh and bold look.\n\nTranslated with www.DeepL.com/Translator (free version)</p>', '<p>DESCRIPTION\nBeautiful patterns framed by black window trims\n \n\nChoosing a dark colour for window frames or painting the trim black is a clever trick that can offer a number of benefits. Black is a timeless neutral. It has always been elegant and goes with everything. However, black is also a very strong colour and should be used in moderation. A few accent details are enough to make the decoration stand out. Black window frames can be such features.\n\nSince black is neutral, it can be combined with other neutrals to create pleasant and inviting decor. Anne Decker Architects, for example, chose black as the colour for window frames to create a more natural and seamless connection to the outdoors. The overall decor is nicely balanced. The black frames contrast with the white walls, while blending in better with the views.\n\nArchitect chose black for the thin window frames, but also for the stair railings, and it creates a beautiful cohesion in the space. The windows and staircase also add a graphic look to the decor. Moreover, the contrast between the black lines and the white walls and ceilings enlivens the space and gives it a fresh and bold look.\n\nTranslated with www.DeepL.com/Translator (free version)</p>', '<p>DESCRIPTION\nBeautiful patterns framed by black window trims\n \n\nChoosing a dark colour for window frames or painting the trim black is a clever trick that can offer a number of benefits. Black is a timeless neutral. It has always been elegant and goes with everything. However, black is also a very strong colour and should be used in moderation. A few accent details are enough to make the decoration stand out. Black window frames can be such features.\n\nSince black is neutral, it can be combined with other neutrals to create pleasant and inviting decor. Anne Decker Architects, for example, chose black as the colour for window frames to create a more natural and seamless connection to the outdoors. The overall decor is nicely balanced. The black frames contrast with the white walls, while blending in better with the views.\n\nArchitect chose black for the thin window frames, but also for the stair railings, and it creates a beautiful cohesion in the space. The windows and staircase also add a graphic look to the decor. Moreover, the contrast between the black lines and the white walls and ceilings enlivens the space and gives it a fresh and bold look.\n\nTranslated with www.DeepL.com/Translator (free version)</p>'),
(4, '<h2>BEMUTATKOZÁS</h2><p>&nbsp;</p><h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2>BEMUTATKOZÁS</h2><p>&nbsp;</p><h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2>BEMUTATKOZÁS</h2><p>&nbsp;</p><h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2>BEMUTATKOZÁS</h2><p>&nbsp;</p><h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<h2>BEMUTATKOZÁS</h2><p>&nbsp;</p><h2><strong>Gyönyörű minták, amelyeket fekete ablak kárpitok kereteznek</strong></h2><p>&nbsp;</p><p>Az ablakkeretek sötét színének kiválasztása vagy a díszítés fekete festése ügyes trükk, amely számos előnyt kínálhat. A fekete egy időtlen semleges. Mindig elegáns volt és mindenhez passzol. Ugyanakkor a fekete is nagyon erős szín, és mértékkel kell használni. Néhány ékezetes részlet elegendő ahhoz, hogy a dekoráció feltűnjön. A fekete ablakkeretek lehetnek ilyen jellemzők.</p><p>Mivel a fekete semleges, más semlegesekkel kombinálva kellemes és hívogató dekorok hozhatók létre. Például az <a href=\"http://www.annedeckerarchitects.com/\">Anne Decker Architects</a> a feketét választotta az ablakkeretek színének annak érdekében, hogy természetesebb és zökkenőmentesebb kapcsolatot teremtsen a szabadban. Az általános dekoráció szépen kiegyensúlyozott. A fekete keretek ellentétben állnak a fehér falakkal, ugyanakkor jobban beleolvadnak a nézetekbe.</p><p>építész a feketét választotta a vékony ablakkeretekhez, de a lépcső korlátjaihoz is, és ez gyönyörű kohéziót teremt a térben. Az ablakok és a lépcső is grafikus megjelenést kölcsönöz a dekorációnak. Sőt, a fekete vonalak és a fehér falak és mennyezetek közötti kontraszt élénkíti a teret, és friss és merész megjelenést kölcsönöz neki.</p>', '<p>oldal1 szerkesztése angolul jo</p>', '<p>oldal1 szerkesztése angolul</p>', '<p>oldal1 szerkesztése angolul</p>', '<p>oldal1 szerkesztése angolul</p>', '<p>oldal1 szerkesztése angolul</p>'),
(8, '<p>ww</p>', '<p>ww</p>', '<p>ww</p>', '<p>ww</p>', '<p>ww</p>', '<p>oldal13 szerkesztése angolul</p>', '<p>oldal13 szerkesztése angolul</p>', '<p>oldal13 szerkesztése angolul</p>', '<p>oldal13 szerkesztése angolul</p>', '<p>oldal13 szerkesztése angolul</p>'),
(14, '<p>.oldal19 szerkesztése</p>', '<p>.oldal19 szerkesztése</p>', '<p>.oldal19 szerkesztése</p>', '<p>.oldal19 szerkesztése</p>', '<p>.oldal19 szerkesztése</p>', '<p>fff</p>', '<p>fff</p>', '<p>fff</p>', '<p>fff</p>', '<p>fff</p>'),
(34, '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>', '<p>oldal5 szerkesztése szerkesztése</p>');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(40) NOT NULL,
  `user_email` varchar(60) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `joining_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_pass`, `joining_date`) VALUES
(2, 'Tomi', 'dobiasz.tamas@gmail.com', '$2y$10$EBbXUzB1IWcbcWWTiHRwVeN4tRXoyzXnSAagk1nIU9IubdwCh6t3S', '2019-10-23 12:20:17'),
(8, 'Nelli', 'fekete.totya@gmail.com', '$2y$10$3Alx7FJSHmVE3rnzmsNFCObIG1xMNRNFoz8cdfxDAE4uAZrK6/xvu', '2021-07-25 22:18:02'),
(9, 'Nagy Valaki', 'valaki@gmail.com', '$2y$10$KIJrjTZWG3AWypBY9OWApOnn7xrhDWixEiDLCVRMXPZrZUTVPZasu', '2021-05-17 19:13:02'),
(10, 'Duci Juci', 'juci.duci@freemail.hu', '$2y$10$caZR6Edlt0VXaqBi4KNb6e91A2A.oqkPwuPYFjmakXLjCYmZ0wk0i', '2021-07-17 11:07:28'),
(11, 'Nagy Zénó', 'zeno@gmail.com', '$2y$10$29/5bbTXUGwR8mznWRsffeq8c9uq9BAAY3cFJyK/IcKXejYD3.yhC', '2021-07-18 09:48:27');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `aloldalak`
--
ALTER TABLE `aloldalak`
  ADD PRIMARY KEY (`al_oldalak_id`);

--
-- A tábla indexei `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`footer_id`);

--
-- A tábla indexei `footeren`
--
ALTER TABLE `footeren`
  ADD PRIMARY KEY (`footer_id`);

--
-- A tábla indexei `meta`
--
ALTER TABLE `meta`
  ADD PRIMARY KEY (`meta_id`);

--
-- A tábla indexei `navmenu`
--
ALTER TABLE `navmenu`
  ADD PRIMARY KEY (`nav_id`);

--
-- A tábla indexei `oldalak`
--
ALTER TABLE `oldalak`
  ADD PRIMARY KEY (`oldalak_id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `aloldalak`
--
ALTER TABLE `aloldalak`
  MODIFY `al_oldalak_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT a táblához `footer`
--
ALTER TABLE `footer`
  MODIFY `footer_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `meta`
--
ALTER TABLE `meta`
  MODIFY `meta_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `navmenu`
--
ALTER TABLE `navmenu`
  MODIFY `nav_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `oldalak`
--
ALTER TABLE `oldalak`
  MODIFY `oldalak_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
