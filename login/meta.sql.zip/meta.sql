-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Gép: localhost
-- Létrehozás ideje: 2021. Jún 21. 00:13
-- Kiszolgáló verziója: 10.3.28-MariaDB-cll-lve
-- PHP verzió: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `caribihu_vip`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `meta`
--

CREATE TABLE `meta` (
  `meta_id` int(20) NOT NULL,
  `metaleiras` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `metaleiras2` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_hungarian_ci NOT NULL,
  `oldalneve` varchar(2550) COLLATE utf8_hungarian_ci NOT NULL,
  `banner` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `banner2` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `banner3` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `meta`
--

INSERT INTO `meta` (`meta_id`, `metaleiras`, `metaleiras2`, `oldalneve`, `banner`, `banner2`, `banner3`, `h1`) VALUES
(1, 'szemetes illatosÃ­tÃ³, illatosÃ­tÃ³, caribi', 'szemetes illatosÃ­tÃ³, caribi', 'Fresh Stick.php', 'OTTHONI SZEMETES ILLATOSÃTÃ“ CARIBI', 'SZEMETES CARIBI ILLATOSÃTÃ“ ', 'IRODAI SZEMETES ILLATOSÃTÃ“ CARIBI', 'SZEMETES ILLATOSÃTÃ“ OTTHONRA '),
(2, 'LÃ©gkondi illatosÃ­tÃ³', 'LÃ©gkondi illatosÃ­tÃ³', 'airconditioner.php', 'CARIBI LÃ‰GKONDI ILLATOSÃTÃ“', 'LÃ‰GKONDI ILLATOSÃTÃ“ REMEK VÃLASZTÃS', 'CARIBI LÃ‰GKONDI ILLATOSÃTÃ“', 'LENYÃœGÃ–ZÅ MINÃ–SSÃ‰GÅ° ILLATOSÃTÃ“ A LÃ‰GKONDIHOZ'),
(3, 'CARIBI KÃœLÃ–NLEGES AUTÃ“ILLATOSÃTÃ“, autÃ³illatosÃ­tÃ³k vip, illatosÃ­tÃ³k, vip', 'autÃ³ illatosÃ­tÃ³, illatosÃ­tÃ³, caribi', 'dryair.php', 'CARIBI PRÃ‰MIUM MINÅSSÃ‰GÅ° AUTÃ“ILLATOSÃTÃ“INK', 'CARIBI AUTÃ“ILLATOSÃTÃ“INK', 'PRÃ‰MIUM MINÅSSÃ‰GÅ° AUTÃ“ILLATOSÃTÃ“ CARIBI', 'CARIBI PRÃ‰MIUM MINÅSSÃ‰GÅ° AUTÃ“ILLATOSÃTÃ“INK'),
(4, 'SZOBAILLATOSÃTÃ“ TERMÃ‰KEINK, szobaillatosÃ­tÃ³k, lakÃ¡sillatosÃ­tÃ³k, caribi', 'szobaillatosÃ­tÃ³k, lakÃ¡sillatosÃ­tÃ³k, caribi', 'homestick.php', 'CARIBI SZOBAILLATOSÃTÃ“K BUBLE GUM', 'KIVÃLLÃ“ SZOBAILLATOSÃTÃ“K', 'PRÃ‰MIUM SZOBAILLATOSÃTÃ“ CARIBI TERMÃ‰K', 'SZOBAILLATOSÃTÃ“ TERMÃ‰KEINK'),
(5, 'VIP KÃœLÃ–NLEGES AUTÃ“ILLATOSÃTÃ“, autÃ³illatosÃ­tÃ³k vip, illatosÃ­tÃ³k, vip', 'VIP PRÃ‰MIUM MINÅSSÃ‰GI ILLATOSÃTÃ“INK', 'index.php', 'VIP KÃœLÃ–NLEGES AUTÃ“ILLATOSÃTÃ“', 'VIP AUTÃ“ILLATÃ“SÃTÃ“INK ', 'VIP AUTÃ“ILLATÃ“SÃTÃ“ MELY KÃœLÃ–NLEGES AJÃNDÃ‰K', 'VIP PRÃ‰MIUM MINÅSSÃ‰GI ILLATOSÃTÃ“INK'),
(6, 'autÃ³illatosÃ­tÃ³k, vanillia, eper, QEEN ORGANIC, meggy', 'autÃ³illatosÃ­tÃ³k CARIBI', 'qeenorganic.php', ' QUEEN ORGANIC AUTÃ“ILLATOSÃTÃ“ TERMÃ‰K', ' QUEEN ORGANIC PRÃ‰MIUM MINÅSSÃ‰GI AUTÃ“ILLATOSÃTÃ“', ' QUEEN ORGANIC TERMÃ‰KINK', ' QUEEN ORGANIC PRÃ‰MIUM MINÅSSÃ‰GI AUTÃ“ILLATOSÃTÃ“'),
(7, 'porszÃ­vÃ³ illatosÃ­tÃ³', 'porszÃ­vÃ³ illatosÃ­tÃ³', 'vacuumcleaner.php', 'KIVÃLLÃ“ PORSZÃVÃ“ ILLATOSÃTÃ“ TERMÃ‰KEINK', 'KItÃ¼nÅ‘ PORSZÃVÃ“ ILLATOSÃTÃ“k', 'KIVÃLLÃ“ PORSZÃVÃ“ ILLATOSÃTÃ“ TERMÃ‰KEINK', 'PORSZÃVÃ“ ILLATOSÃTÃ“ TERMÃ‰KEINK'),
(8, 'fa autÃ³illatosÃ­tÃ³, autÃ³illatosÃ­tÃ³ caribi wood', 'fa autÃ³illatosÃ­tÃ³, autÃ³illatosÃ­tÃ³ caribi wood', 'wood.php', 'WOOD AUTÃ“ILLATOSÃTÃ“', 'WOOD PRÃ‰MIUM MINÅSSÃ‰GI AUTÃ“ILLATOSÃTÃ“', 'AUTÃ“ILLATOSÃTÃ“ WOOD', 'WOOD PRÃ‰MIUM MINÅSSÃ‰GI AUTÃ“ILLATOSÃTÃ“'),
(9, 'AUTÃ“ PARFÃœM, PARFÃœM, ILLATOSÃTÃ“ ', 'VIP PARFÃœM ILLATOSÃTÃ“ AUTÃ“BA', 'goldcarparfum.php', 'VIP PARFÃœM ILLATOSÃTÃ“ AUTÃ“BA', 'AUTÃ“ PARFÃœM ILLATOSÃTÃ“', 'PARFÃœM ILLATOSÃTÃ“ AUTÃ“', 'VIP CAR PARFUM');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `meta`
--
ALTER TABLE `meta`
  ADD PRIMARY KEY (`meta_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `meta`
--
ALTER TABLE `meta`
  MODIFY `meta_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
